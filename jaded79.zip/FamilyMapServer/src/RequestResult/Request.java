package RequestResult;

abstract public class Request {
}
